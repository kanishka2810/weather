package MyPackage;

import jakarta.servlet.ServletException;
import java.io.PrintWriter;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.RequestDispatcher;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String userId = request.getParameter("email");
		String pass = request.getParameter("password");
		try
		{
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/weather","root","Pulkit@1234");
		PreparedStatement ps=con.prepareStatement("select * from login where email='admin@123' and password='admin' ");
		ResultSet rs=ps.executeQuery();
		System.out.println(rs);
		
		if(rs.next())
		{
		//HttpSession session=request.getSession();
		//session.setAttribute("session_name", rs.getString("name"));
		//RequestDispatcher rd=request.getRequestDispatcher("/login.jsp");
		//rd.include(request, response);
		response.sendRedirect("index.jsp");
		}
		else
		{
		response.setContentType("text/html");
		out.print("<h3> didnot mach</h3>");
		RequestDispatcher rd=request.getRequestDispatcher("/loginServlet.jsp");
		rd.include(request, response);
		}
		
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
;