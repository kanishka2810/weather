package MyPackage;

import jakarta.servlet.ServletException;
import java.io.PrintWriter;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.RequestDispatcher;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.sql.Connection;
import java.sql.DriverManager;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import java.util.List;
/**
/**
 * Servlet implementation class GetCityServlet
 */
@WebServlet("/GetCityServlet")
public class GetCityServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetCityServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		List<String> dataList = new ArrayList<>();
		try
		{
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/weather","root","Pulkit@1234");
		PreparedStatement ps=con.prepareStatement("select * from city_name");
		ResultSet rs=ps.executeQuery();
		System.out.println(rs);
		while (rs.next()) {
            String city = rs.getString("city");

            // Example: Format data as needed (here, just adding to list)
            dataList.add(city);
        }
		System.out.println(dataList);
		 String[] countries = {"USA", "Canada", "UK", "Australia"};
		 String message = "Hello from Servlet!";
		 System.out.println(message);
		  
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		request.setAttribute("dataList", dataList);
		 RequestDispatcher dispatcher =  request.getRequestDispatcher("index.jsp");
	        dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
